mkdir /data/data/com.youtube.clone
mkdir /data/data/com.google.service

su -c chmod 777 /data/data/com.republic.hax/files/gl.sh 
su -c chmod 777 /data/data/com.republic.hax/files/kr.sh 
su -c chmod 777 /data/data/com.republic.hax/files/vn.sh 
su -c chmod 777 /data/data/com.republic.hax/files/tw.sh 
su -c chmod 777 /data/data/com.republic.hax/files/bgmi.sh
su -c chmod 777 /data/data/com.republic.hax/files/rgl.sh 
su -c chmod 777 /data/data/com.republic.hax/files/rkr.sh 
su -c chmod 777 /data/data/com.republic.hax/files/rvn.sh 
su -c chmod 777 /data/data/com.republic.hax/files/rtw.sh 
su -c chmod 777 /data/data/com.republic.hax/files/rbgmi.sh

mv /data/data/com.republic.hax/files/RepublicDaemon /data/data/com.google.service
mv /data/data/com.republic.hax/files/Republic /data/data/com.google.service
mv /data/data/com.republic.hax/files/libarm.so /data/data/com.google.service
mv /data/data/com.republic.hax/files/republic /data/data/com.google.service
mv /data/data/com.republic.hax/files/gl.sh /data/data/com.youtube.clone
mv /data/data/com.republic.hax/files/kr.sh /data/data/com.youtube.clone
mv /data/data/com.republic.hax/files/vn.sh /data/data/com.youtube.clone
mv /data/data/com.republic.hax/files/tw.sh /data/data/com.youtube.clone
mv /data/data/com.republic.hax/files/bgmi.sh /data/data/com.youtube.clone
mv /data/data/com.republic.hax/files/remover.sh /data/data/com.youtube.clone

mv /data/data/com.republic.hax/files/gms.sh /data/data/com.youtube.clone
mv /data/data/com.republic.hax/files/flush.sh /data/data/com.youtube.clone
mv /data/data/com.republic.hax/files/fstrim.sh /data/data/com.youtube.clone

